Mapped Standards:
- ISO 14001 – Environmental
- ISO 55001 – Asset Management
- IEC 61508 – Functional Safety
- ISO/IEC 27001 – Cybersecurity
- ISO/IEC 23894 – AI Risk