AI Governance Principles:
- Human‑in‑command
- Explainability required
- No surveillance or enforcement use
- Compliance with ISO/IEC 23894