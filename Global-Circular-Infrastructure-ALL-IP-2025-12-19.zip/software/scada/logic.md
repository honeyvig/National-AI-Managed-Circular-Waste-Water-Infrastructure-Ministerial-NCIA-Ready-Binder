PLC (Safety Layer) → SCADA → AI Advisory → Human Operator

Rules:
- AI never bypasses PLC
- Manual override always available
- All actions immutably logged