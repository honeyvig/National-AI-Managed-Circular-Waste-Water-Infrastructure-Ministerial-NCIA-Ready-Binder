class FlowOptimizer:
    def decide(self, toxicity, flow, capacity):
        if toxicity > 0.8:
            return "ISOLATE_NODE"
        if flow / capacity < 0.7:
            return "NORMAL_OPERATION"
        return "LOAD_BALANCE"