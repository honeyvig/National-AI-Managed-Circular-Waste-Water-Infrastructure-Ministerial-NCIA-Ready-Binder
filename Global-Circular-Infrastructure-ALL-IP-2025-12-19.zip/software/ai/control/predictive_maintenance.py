def failure_probability(vibration, pressure, temperature):
    score = 0.4*vibration + 0.3*pressure + 0.3*temperature
    return min(score, 1.0)