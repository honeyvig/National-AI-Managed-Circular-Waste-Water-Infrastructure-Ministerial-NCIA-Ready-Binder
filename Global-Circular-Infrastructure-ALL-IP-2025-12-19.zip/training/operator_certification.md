Certification Levels:
1. Operator
2. Engineer
3. Auditor
4. National Supervisor