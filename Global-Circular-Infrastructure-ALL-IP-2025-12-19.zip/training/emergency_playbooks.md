Scenarios:
- Urban flooding
- Toxic spill
- AI degradation
- Cyber intrusion
- Grid failure