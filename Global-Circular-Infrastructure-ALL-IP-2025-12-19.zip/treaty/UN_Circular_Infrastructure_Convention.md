Draft multilateral convention for global adoption of
circular waste & water infrastructure.