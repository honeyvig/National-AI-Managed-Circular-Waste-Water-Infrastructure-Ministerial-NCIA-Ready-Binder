## National Circular Infrastructure Architecture

Inputs:
- Municipal waste
- Industrial effluent
- Stormwater

Outputs:
- Reclaimed water
- Energy (biogas, heat)
- Recovered materials

Design principles:
- Zero discharge
- Redundancy
- Fail‑safe by default