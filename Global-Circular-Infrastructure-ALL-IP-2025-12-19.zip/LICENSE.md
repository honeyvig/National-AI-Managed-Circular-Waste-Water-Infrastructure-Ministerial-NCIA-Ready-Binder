INTELLECTUAL PROPERTY NOTICE

This repository contains proprietary frameworks, architectures, and documentation.
Reuse, modification, or deployment requires explicit authorization from the IP holder
or adoption under a sovereign / public‑interest license.