Security Doctrine:
- Infrastructure treated as strategic asset
- Air‑gapped PLCs
- Segmented networks
- Incident escalation matrix