This directory holds:
- Sensor datasets
- Simulation outputs
- Audit logs
(Data populated during deployment)